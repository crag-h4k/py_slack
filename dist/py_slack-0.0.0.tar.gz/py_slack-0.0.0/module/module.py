from time import sleep

def func(x):
    sleep(1)
    return
